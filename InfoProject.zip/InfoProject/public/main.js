// var url =
//   "https://livescore-api.com/api-client/leagues/table.json?key=uLglpq0ZNpVU00UK&secret=owoQXfXvrkyPBSj6Dzr20s2ORYIRYDCn&league=74&season=4";
// fetch(url).then(function (res) {
//   console.log("HIIIII");
//   console.log("RSS", res);
//   return res, json();
// });
